#ifndef CAMERA_H
#define CAMERA_H
#include <openmvrpc.h>

class Camera 
{
  private:
  openmv::rpc_i2c_master *interface;
  
  public:
  Camera(openmv::rpc_i2c_master *intface);
  void begin();
  void exe_face_detection(); // Face should be about 2ft away.
  void exe_person_detection();
  void exe_qrcode_detection(); // Place the QRCode about 2ft away.
  void exe_apriltag_detection();
  void exe_datamatrix_detection(); // Place the Datamatrix about 2ft away.
  void exe_barcode_detection(); // Place the Barcode about 2ft away.
  void exe_color_detection(int8_t l_min, int8_t l_max, int8_t a_min, int8_t a_max, int8_t b_min, int8_t b_max);
  void exe_led_detection();
};
#endif

#include "Camera.h"
#include <Wire.h>
#include <Arduino.h>
#include <openmvrpc.h>

Camera::Camera(openmv::rpc_i2c_master *intface){
  interface = intface;
}

void Camera::begin(){
  
}

void Camera::exe_face_detection(){
    struct { uint16_t x, y, w, h; } face_detection_result;
    if (interface->call_no_args(F("face_detection"), &face_detection_result, sizeof(face_detection_result))) {
        Serial.print(F("Largest Face Detected [x="));
        Serial.print(face_detection_result.x);
        Serial.print(F(", y="));
        Serial.print(face_detection_result.y);
        Serial.print(F(", w="));
        Serial.print(face_detection_result.w);
        Serial.print(F(", h="));
        Serial.print(face_detection_result.h);
        Serial.println(F("]"));
    }
}
  
void Camera::exe_person_detection(){
    char buff[32 + 1] = {}; // null terminator
    if (interface->call_no_args(F("person_detection"), buff, sizeof(buff) - 1)) {
        Serial.println(buff);
    }
}

void Camera::exe_qrcode_detection(){
    char buff[128 + 1] = {}; // null terminator
    if (interface->call_no_args(F("qrcode_detection"), buff, sizeof(buff) - 1)) {
        Serial.print("qrdetected: ");
        Serial.println(buff);
    }
}

void Camera::exe_apriltag_detection(){
    struct { uint16_t cx, cy, id, rot; } apriltag_detection_result;
    if (interface->call_no_args(F("apriltag_detection"), &apriltag_detection_result, sizeof(apriltag_detection_result))) {
        Serial.print(F("Largest Tag Detected [cx="));
        Serial.print(apriltag_detection_result.cx);
        Serial.print(F(", cy="));
        Serial.print(apriltag_detection_result.cy);
        Serial.print(F(", id="));
        Serial.print(apriltag_detection_result.id);
        Serial.print(F(", rot="));
        Serial.print(apriltag_detection_result.rot);
        Serial.println(F("]"));
    }
}

void Camera::exe_datamatrix_detection(){
    char buff[128 + 1] = {}; // null terminator
    if (interface->call_no_args(F("datamatrix_detection"), buff, sizeof(buff) - 1)) {
        Serial.println(buff);
    }
}

void Camera::exe_barcode_detection(){
    char buff[128 + 1] = {}; // null terminator
    if (interface->call_no_args(F("barcode_detection"), buff, sizeof(buff) - 1)) {
        Serial.println(buff);
    }
}
  
void Camera::exe_color_detection(int8_t l_min, int8_t l_max, int8_t a_min, int8_t a_max, int8_t b_min, int8_t b_max){
    //int8_t color_thresholds[6] = {l_min, l_max, a_min, a_max, b_min, b_max};
    int8_t color_thresholds[6] = {26, 100, -108, -9, 0, -42};
    //struct { uint16_t cx, cy; } color_detection_result;
    short buff[128 + 1] = {};
    if (interface->call(F("color_detection"), color_thresholds, sizeof(color_thresholds), buff, sizeof(buff)-1)) {
//        Serial.print(F("Largest Color Detected [cx="));
//        Serial.print(color_detection_result.cx);
//        Serial.print(F(", cy="));
//        Serial.print(color_detection_result.cy);
//        Serial.println(F("]"));
          int i = 0;
          Serial.println("green detected");
          while (buff[i] != '\0' && i<100) {
            Serial.print(buff[i]);
            i++;  
          }
          Serial.println("");
    }
}

void Camera::exe_led_detection(){
      //int8_t color_thresholds[6] = {l_min, l_max, a_min, a_max, b_min, b_max};
    int8_t color_thresholds[6] = {26, 100, -108, -9, 0, -42};
    //struct { uint16_t cx, cy; } color_detection_result;
    short buff[128 + 1] = {};
    if (interface->call(F("LED_detection"), color_thresholds, sizeof(color_thresholds), buff, sizeof(buff)-1)) {
          int i = 0;
          Serial.println("LED detected");
          while (buff[i] != '\0' && i<100) {
            Serial.print(buff[i]);
            i++;  
          }
          Serial.println("");
    }
}
